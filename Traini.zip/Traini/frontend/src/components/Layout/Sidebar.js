import React, { useState } from 'react';
import { Drawer, List, ListItem, ListItemText, Divider, IconButton, Button, ListItemIcon } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import SupervisedUserCircleIcon from '@mui/icons-material/SupervisedUserCircle';
import PersonOutlineIcon from '@mui/icons-material/PersonOutline';
import AddBoxIcon from '@mui/icons-material/AddBox';
import GroupAddIcon from '@mui/icons-material/GroupAdd';
import GroupIcon from '@mui/icons-material/Group';
import PeopleAltIcon from '@mui/icons-material/PeopleAlt';

import TrainIcon from '@mui/icons-material/Train';
import QuizIcon from '@mui/icons-material/Quiz';
import ChatIcon from '@mui/icons-material/Chat';
import DescriptionIcon from '@mui/icons-material/Description'; // Use DescriptionIcon as an alternative
import PlaylistAddCheckIcon from '@mui/icons-material/PlaylistAddCheck'; // Use PlaylistAddCheckIcon as an alternative
const sidebarStyle = {
  width: '250px',
  color: 'white',
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'space-between',
  height: '100%',
  background: 'green',
};

const listStyle = {
  listStyle: 'none',
  margin: 0,
  padding: 0,
  position: 'relative',
  paddingTop: '8px',
  paddingBottom: '8px',
  background: 'green',
};

const subOptionStyle = {
  paddingLeft: '40px',
};

const textStyle = {
  color: 'white',
};

// ... (previous imports and component definition)

const Sidebar = ({ open, handleSidebarToggle, userRole }) => {

  console.log("userRole",userRole?userRole:"");
  const [superAdminOpen, setSuperAdminOpen] = useState(false);

  const toggleSuperAdmin = () => {
    setSuperAdminOpen(!superAdminOpen);
  };

  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');

    navigate('/login');
  };

  return (
    <Drawer
      variant="persistent"
      anchor="left"
      open={open}
      style={sidebarStyle}
    >
      <List style={listStyle}>
        <ListItem button onClick={handleSidebarToggle}>
          <IconButton>
            <ChevronLeftIcon style={{ color: 'white' }} />
          </IconButton>
        </ListItem>
        <Divider />
        {userRole === 'superadmin' && (
          <div>
            <ListItem button onClick={toggleSuperAdmin}>
              <ListItemIcon>
                <SupervisedUserCircleIcon style={{ color: 'white' }} />
              </ListItemIcon>
              <ListItemText primary="Super Admin" style={textStyle} />
            </ListItem>
            {superAdminOpen && (
              <List component="div" style={subOptionStyle}>
                <ListItem button component={Link} to="/super-admin">
                  <ListItemIcon>
                    <AddBoxIcon style={{ color: 'white' }} /> {/* Add an icon */}
                  </ListItemIcon>
                  <ListItemText primary="Create User" style={textStyle} />
                </ListItem>
               
                <ListItem button component={Link} to="/adminlist">
                  <ListItemIcon>
                    <GroupIcon style={{ color: 'white' }} /> {/* Add an icon */}
                  </ListItemIcon>
                  <ListItemText primary="Admin List" style={textStyle} />
                </ListItem>
                <ListItem button component={Link} to="/traineelist">
                  <ListItemIcon>
                    <PeopleAltIcon style={{ color: 'white' }} /> {/* Add an icon */}
                  </ListItemIcon>
                  <ListItemText primary="Trainee List" style={textStyle} />
                </ListItem>
              </List>
            )}
          </div>
        )}
        {userRole === 'admin' && (
          <div>
            <ListItem button component={Link} to="/admin">
              <ListItemIcon>
                <SupervisedUserCircleIcon style={{ color: 'white' }} />
              </ListItemIcon>
              <ListItemText primary="Admin" style={textStyle} />
            </ListItem>
            <List component="div" style={subOptionStyle}>
              <ListItem button component={Link} to="/admin">
                <ListItemIcon>
                  <AddBoxIcon style={{ color: 'white' }} /> {/* Add an icon */}
                </ListItemIcon>
                <ListItemText primary="Create Trainee" style={textStyle} />
              </ListItem>
              <ListItem button component={Link} to="/upload">
                <ListItemIcon>
                  <PeopleAltIcon style={{ color: 'white' }} /> {/* Add an icon */}
                </ListItemIcon>
                <ListItemText primary="Upload Document" style={textStyle} />
              </ListItem>
              <ListItem button component={Link} to="/traineelist">
                <ListItemIcon>
                  <PeopleAltIcon style={{ color: 'white' }} /> {/* Add an icon */}
                </ListItemIcon>
                <ListItemText primary="Trainee List" style={textStyle} />
              </ListItem>
            </List>
          </div>
        )}
        {userRole === 'trainee' && (
          <div>
          <ListItem button component={Link} to="/trainee">
            <ListItemIcon>
              <PersonOutlineIcon style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="Trainee" style={textStyle} />
          </ListItem>
          <ListItem button component={Link} to="/quiz">
            <ListItemIcon>
              <QuizIcon style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="Attempt Quiz" style={textStyle} />
          </ListItem>
          <ListItem button component={Link} to="/chat">
            <ListItemIcon>
              <ChatIcon style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="Chat" style={textStyle} />
          </ListItem>
          <ListItem button component={Link} to="/summary">
            <ListItemIcon>
              <DescriptionIcon style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="Summary" style={textStyle} />
          </ListItem>
          <ListItem button component={Link} to="/keypoint">
            <ListItemIcon>
              <PlaylistAddCheckIcon style={{ color: 'white' }} />
            </ListItemIcon>
            <ListItemText primary="Key Points" style={textStyle} />
          </ListItem>
          </div>
          
        )}
      </List>
      <div style={{ flexGrow: 1 }}></div>
      <Divider />
      <List>
  <ListItem>
    <Button
      variant="contained"
      color="warning" // Change to primary color
      fullWidth
      onClick={handleLogout}
    >
      Logout
    </Button>
  </ListItem>
</List>

    </Drawer>
  );
};



export default Sidebar;
