import React from 'react';
import { AppBar, Toolbar, IconButton, Typography, Button, Menu, MenuItem } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import AccountCircleIcon from '@mui/icons-material/AccountCircle'; 
import { Link, useNavigate } from 'react-router-dom';

const Header = ({ handleSidebarToggle }) => {
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    handleLogout();
    setAnchorEl(null);
  };
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');

    navigate('/login');
  };

  return (
    <AppBar position="fixed" style={{ zIndex: 1201 }}>
      <Toolbar>
        <IconButton
          color="inherit"
          aria-label="open sidebar"
          onClick={handleSidebarToggle}
          edge="start"
        >
          <MenuIcon />
        </IconButton>
        <Typography variant="h6" style={{ flex: 1, color: 'white' }}>
        Train.Ai
        </Typography>
        <IconButton
          color="inherit"
          aria-label="profile"
          onClick={handleMenuOpen}
        >
          <AccountCircleIcon style={{ fontSize: '32px', color: 'white' }} />
        </IconButton>
        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
        >
          <MenuItem
            onClick={handleMenuClose}
            component={Link}
            to="/profile"
            style={{ color: '#2196F3' }}
          >
            Profile
          </MenuItem>
          <MenuItem
            onClick={handleMenuClose}
         
            style={{ color: '#F44336' }}
          >
            Logout
          </MenuItem>
        </Menu>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
