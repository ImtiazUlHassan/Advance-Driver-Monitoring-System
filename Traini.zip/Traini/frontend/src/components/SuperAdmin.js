import React, { useState, useEffect } from 'react';
import { Button, Container, Typography, Box } from '@mui/material';
import axios from 'axios';
import UserForm from './UserForm';

function SuperAdmin() {
  const [admins, setAdmins] = useState([]);
  const roles = ['admin', 'trainee'];

  // Fetch the list of Admins when the component mounts
  useEffect(() => {
    fetchAdmins();
  }, []);

  const addAdmin = (admin) => {
    // Add the new admin to the state
    setAdmins([...admins, admin]);
  };

  const fetchAdmins = async () => {
    try {
      const response = await axios.get('http://127.0.0.1:8000/api/admins/');
      setAdmins(response.data);
    } catch (error) {
      console.error('Error fetching Admins', error);
    }
  };

  const createAdmin = async (adminData) => {
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/admin/create/', adminData);
      addAdmin(response.data);
    } catch (error) {
      console.error('Error creating Admin', error);
    }
  };

  return (
    <Container maxWidth="sm" style={{ marginTop: '80px' }}>
      <Box my={4}>
        <Typography variant="h4" component="h1">
          Add Admin
        </Typography>
        <UserForm onSubmit={createAdmin} roles={roles} userType="Admin" />
      </Box>
    </Container>
  );
}



export default SuperAdmin;
