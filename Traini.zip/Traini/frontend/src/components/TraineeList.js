import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Container,
  Paper,
  Typography,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  IconButton,
  Box,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';

const TraineeUserList = () => {
  const [adminUsers, setAdminUsers] = useState([]);

  useEffect(() => {
    const fetchAdminUsers = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/trainee-users');
        setAdminUsers(response.data);
      } catch (error) {
        console.error('Error fetching admin users', error);
      }
    };

    fetchAdminUsers();
  }, []);

  
  const handleDeleteAdmin = async (userId) => {
    try {
      await axios.delete('http://127.0.0.1:8000/api/deletetrainee', { data: { id: userId } });
      setAdminUsers(adminUsers.filter(user => user.id !== userId));
    } catch (error) {
      console.error('Error deleting admin user', error);
    }
  };

  return (
    <Container maxWidth="md" sx={{mt:10}}>
      <Paper elevation={3} style={{ padding: '20px' }}>
        <Typography variant="h4" gutterBottom>
         Trainee Users
        </Typography>
        {adminUsers.length > 0 ? (
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell style={{ fontWeight: 'bold' }}>Name</TableCell>
                  <TableCell style={{ fontWeight: 'bold' }}>Email</TableCell>
                  <TableCell style={{ fontWeight: 'bold' }}>Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {adminUsers.map((user) => (
                  <TableRow key={user.id} style={{ borderBottom: '1px solid #ddd' }}>
                    <TableCell>{user.username}</TableCell>
                    <TableCell>{user.email}</TableCell>
                    <TableCell>
                      <IconButton
                        edge="end"
                        aria-label="delete"
                        onClick={() => handleDeleteAdmin(user.id)}
                      >
                        <DeleteIcon style={{ color: 'red' }} />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        ) : (
          <Box mt={2}>
            <Typography variant="subtitle1">No Trainee users found.</Typography>
          </Box>
        )}
      </Paper>
    </Container>
  );
};

export default TraineeUserList;
