import React, { useState } from 'react';
import UserForm from './UserForm';
import axios from 'axios';

function Admin() {
  const [trainees, setTrainees] = useState([]);

  const addTrainee = (trainee) => {
    setTrainees([...trainees, trainee]);
  };
// Admin.js
// ...
const roles = ['trainee'];
// ...
const createAdmin = async (adminData) => {
  try {
    const response = await axios.post('http://127.0.0.1:8000/api/admin/create/', adminData);
    addTrainee(response.data);
  } catch (error) {
    console.error('Error creating Admin', error);
  }
};
  return (
    <div style={{ marginTop: '80px' }}>
      <h2>Admin Dashboard</h2>

      <UserForm onSubmit={createAdmin} roles={roles} userType="Trainee" />
      {/* <TraineeList trainees={trainees} /> */}
    </div>
  );
}

export default Admin;
