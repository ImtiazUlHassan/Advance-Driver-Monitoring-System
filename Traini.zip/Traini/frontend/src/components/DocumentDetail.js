import { Typography, Button, Container, Paper, Grid, Box, TextField } from '@mui/material';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const DocumentDetail = ({ file }) => {
  const [selectedOption, setSelectedOption] = useState(null);
  const [summary, setSummary] = useState('');
  const [quiz, setQuiz] = useState([]);
  const [keyPoints, setKeyPoints] = useState('');
  const [editableContent, setEditableContent] = useState('');
const [newQuestions, setNewQuestions] = useState([...Array(15)].map(() => ({ question: '', options: ['', '', '', ''], correctAnswer: '' })));

  const setNewQuestion = (index, key, value, optionIndex = null) => {
    setNewQuestions((prevQuestions) => {
      const newQuestionsCopy = [...prevQuestions];
      if (optionIndex !== null) {
        newQuestionsCopy[index].options[optionIndex] = value;
      } else {
        newQuestionsCopy[index][key] = value;
      }
      return newQuestionsCopy;
    });
  };
  const handleOptionClick = (option) => {
    setSelectedOption(option);
  };
 



  const addNewQuestion = () => {
    setNewQuestions((prevQuestions) => ([
      ...prevQuestions,
      {
        question: '',
        options: ['', '', '', ''],
        correctAnswer: 0,
      }
    ]));
  };

  const removeQuestion = (index) => {
    setNewQuestions((prevQuestions) => {
      const newQuestionsCopy = [...prevQuestions];
      newQuestionsCopy.splice(index, 1);
      return newQuestionsCopy;
    });
  };

  
  const [files, setFiles] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/get_uploaded_files')
      .then((response) => {
        setFiles(response.data);
      })
      .catch((error) => {
        console.error('Error fetching files:', error);
      });
  }, []);

  const fetchData = async (userInput, setDataCallback) => {
    if (files.length > 0) {
      try {
        const response = await fetch('http://127.0.0.1:8000/api/generatesummary', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            id: files[0]?.id,
            userinput: userInput,
          }),
        });

        if (response.ok) {
          const data = await response.json();
          setDataCallback(data.summary);
          setEditableContent(data.summary); // Set editable content
        } else {
          console.error(`Failed to fetch ${userInput}`);
        }
      } catch (error) {
        console.error('Error:', error);
      }
    }
  };

  const handleSave = () => {
    if (selectedOption === 'summary') {
      saveToSummaryAPI(editableContent);
    } else if (selectedOption === 'quiz') {
      axios
      .post('http://127.0.0.1:8000/api/savequiz', {
        questions: newQuestions.map((question) => ({
          question_text: question.question,
          option1: question.options[0],
          option2: question.options[1],
          option3: question.options[2],
          option4: question.options[3],
          correct_answer: question.correctAnswer,
        })),
      })
      .then((response) => {
        console.log('Quiz saved successfully:', response.data.message);
      })
      .catch((error) => {
        console.error('Failed to save quiz:', error);
      });
    } else if (selectedOption === 'keyPoints') {
      saveToKeyPointsAPI(editableContent);
    }
    setEditableContent('');
    setNewQuestions(Array(15).fill({ question: '', options: ['', '', '', ''], correctAnswer: '' }));
  };

  const saveToSummaryAPI = (content) => {
    if (files.length > 0) {
      axios.post('http://127.0.0.1:8000/api/savesummary', {
        content: content,
        document_id: files[0]?.id,
      })
        .then((response) => {
          console.log('Summary saved successfully:', response.data.message);
        })
        .catch((error) => {
          console.error('Failed to save summary:', error);
        });
    }
  };

 

  const saveToKeyPointsAPI = (content) => {
    if (files.length > 0) {
      axios.post('http://127.0.0.1:8000/api/savekeypoint', {
        content: content,
        document_id: files[0]?.id,
      })
        .then((response) => {
          console.log('KeyPoint saved successfully:', response.data.message);
        })
        .catch((error) => {
          console.error('Failed to save keypoint:', error);
        });
    }
  };

  useEffect(() => {
    if (selectedOption === 'summary') {
      fetchData('Summarize the Document', setSummary);
    } else if (selectedOption === 'quiz') {
      fetchData('Generate 15 Multiple choice questions with correct answers', setQuiz);
    } else if (selectedOption === 'keyPoints') {
      fetchData('Get the key points from the document', setKeyPoints);
    }
  }, [selectedOption]);

  const DocumentIframe = () => (
    <iframe
      src={'https://www.africau.edu/images/default/sample.pdf'} // Replace with the actual URL or source of the document
      width="100%"
      height="500"
      title="Document"
    ></iframe>
  );

  const renderOption = (title, content) => (
    <Paper elevation={4} sx={{ p: 3, my: 2, bgcolor: 'background.paper' }}>
      <Typography variant="h5" mb={2}>{title}</Typography>
      {editableContent !== ''? (
        <textarea
          value={editableContent}
          onChange={(e) => setEditableContent(e.target.value)}
          rows={10}
          cols={50}
          style={{ width: '100%', marginBottom: '16px' }}
        />
      ) : (
        <Typography>{content}</Typography>
      )}
      {selectedOption === 'quiz' ? (
        <div>
          {newQuestions.map((question, index) => (
            <div key={index}>
              <Typography variant="h6">Question {index + 1}:</Typography>
              <TextField
                label="Question"
                value={question.question}
                onChange={(e) => setNewQuestion(index, 'question', e.target.value)}
                fullWidth
              />
              <Typography variant="h6">Options:</Typography>
              {question.options.map((option, optionIndex) => (
                <TextField
                  key={optionIndex}
                  label={`Option ${optionIndex + 1}`}
                  value={option}
                  onChange={(e) => setNewQuestion(index, 'options', e.target.value, optionIndex)}
                  fullWidth
                />
              ))}
              <TextField
                label="Correct Answer"
                value={question.correctAnswer}
                onChange={(e) => setNewQuestion(index, 'correctAnswer', e.target.value)}
                fullWidth
              />
            </div>
          ))}
          <Button
            variant="contained"
            color="primary"
            onClick={handleSave}
            fullWidth
            sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}
          >
            Save
          </Button>
        </div>
      ) : (
        editableContent !== '' && (
          <Button
            variant="contained"
            color="primary"
            onClick={handleSave}
            fullWidth
            sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}
          >
            Save
          </Button>
        )
      )}
    </Paper>
  );

  return (
    <Container maxWidth="md">
      <Typography variant="h4" component="h1" gutterBottom>
        Document Details
      </Typography>
      <Box my={3}>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleOptionClick('summary')}
              fullWidth
              sx={{ bgcolor: 'primary.main', '&:hover': { bgcolor: 'primary.dark' } }}
            >
              Summary
            </Button>
          </Grid>
          <Grid item xs={4}>
            <Button
              variant="contained"
              color="info"
              onClick={() => handleOptionClick('quiz')}
              fullWidth
              sx={{ bgcolor: 'info.main', '&:hover': { bgcolor: 'info.dark' } }}
            >
              Quiz
            </Button>
          </Grid>
          <Grid item xs={4}>
            <Button
              variant="contained"
              color="success"
              onClick={() => handleOptionClick('keyPoints')}
              fullWidth
              sx={{ bgcolor: 'success.main', '&:hover': { bgcolor: 'success.dark' } }}
            >
              Key Points
            </Button>
          </Grid>
        </Grid>
      </Box>
      {selectedOption === 'summary' && renderOption('Summary', summary)}
      {selectedOption === 'quiz' && renderOption('Quiz', quiz)}
      {selectedOption === 'keyPoints' && renderOption('Key Points', keyPoints)}
      {DocumentIframe()}
    </Container>
  );
};

export default DocumentDetail;
