import React, { useState, useEffect } from "react";
import axios from "axios";

const chatbotContainerStyle = {
  width: "800px",
  margin: "0 auto", // This centers the chatbot horizontally
  marginTop: "100px", // Add space from the top
  padding: "20px",
  backgroundColor: "#fff",
  borderRadius: "10px",
  boxShadow: "0 0 10px rgba(0, 0, 0, 0.2)",
};

const chatStyle = {
  height: "400px",
  overflowY: "scroll",
  padding: "10px",
  backgroundColor: "#f7f7f7",
  borderRadius: "10px",
};

const chatMessageStyle = {
  padding: "10px",
  marginBottom: "10px",
  borderRadius: "10px",
};

const userStyle = {
  backgroundColor: "#007bff",
  color: "white",
  textAlign: "right",
};

const botStyle = {
  backgroundColor: "#eee",
  color: "#333",
};

const chatbotInputStyle = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  padding: "10px",
  borderTop: "1px solid #ccc",
};

const inputStyle = {
  flexGrow: 1,
  padding: "10px",
  border: "1px solid #ccc",
  borderRadius: "10px",
  marginRight: "10px",
};

const buttonStyle = {
  backgroundColor: "#007bff",
  color: "white",
  border: "none",
  borderRadius: "10px",
  padding: "10px 20px",
  cursor: "pointer",
};

const Chatbot = () => {
    const [input, setInput] = useState("");
    const [chat, setChat] = useState([]);
    const [files, setFiles] = useState([]);
  
    const handleInputChange = (event) => {
      setInput(event.target.value);
    };
  
    useEffect(() => {
      axios
        .get("http://127.0.0.1:8000/api/get_uploaded_files")
        .then((response) => {
          setFiles(response.data);
        })
        .catch((error) => {
          console.error("Error fetching files:", error);
        });
    }, []);
  
    const fileId = files.length > 0 ? files[0].id : "";
  
    const handleUserQuery = () => {
      if (input.trim() === "") {
        return;
      }
  
      // Store the user's query in the chat
      setChat((prevChat) => [...prevChat, { text: input, type: "user" }]);
      setInput("");
  
      if (files.length > 0) {
        axios
          .post("http://127.0.0.1:8000/api/generatesummary", {
            userinput: input,
            id: fileId, // Use the fileId as a string
          })
          .then((response) => {
            const botResponse = response.data.summary; // Adjust this based on the actual structure of your API response
            // Store both user query and bot response in the chat
            setChat((prevChat) => [...prevChat, { text: botResponse, type: "bot" }]);
          })
          .catch((error) => {
            console.error("Error fetching response:", error);
          });
      }
    };
  
    return (
      <div style={chatbotContainerStyle}>
        <div style={chatStyle}>
          {chat.map((message, index) => (
            <div
              key={index}
              style={{
                ...chatMessageStyle,
                ...(message.type === "user" ? userStyle : botStyle),
              }}
            >
              {message.text}
            </div>
          ))}
        </div>
        <div style={chatbotInputStyle}>
          <input
            type="text"
            value={input}
            onChange={handleInputChange}
            placeholder="Type your message..."
            style={inputStyle}
          />
          <button onClick={handleUserQuery} style={buttonStyle}>
            Send
          </button>
        </div>
      </div>
    );
  };
  
  export default Chatbot;
  
  

