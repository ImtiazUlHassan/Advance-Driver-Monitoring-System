import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import StarIcon from '@mui/icons-material/Star';

const styles = {
  container: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    minHeight: '100vh',
  },
  card: {
    padding: '20px',
    minHeight: '200px',
    borderRadius: '10px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    background: 'linear-gradient(135deg, #007bff, #52c5f7)',
    color: '#fff',
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: '1rem',
    display: 'flex',
    alignItems: 'center',
  },
  cardContent: {
    fontSize: 18,
  },
  starIcon: {
    color: '#fbc02d',
    fontSize: 28,
    marginLeft: '5px',
  },
  gridContainer: {
    justifyContent: 'center',
  },
};

const QuizResults = () => {
  const [statistics, setStatistics] = useState({});
  const token = localStorage.getItem('token');

  useEffect(() => {
    axios
      .get('http://127.0.0.1:8000/api/quiz-results', {
        headers: {
          Authorization: `Token ${token}`,
        },
      })
      .then((response) => {
        setStatistics(response.data);
      })
      .catch((error) => {
        console.error('Error fetching quiz statistics:', error);
      });
  }, []);

  return (
    <div>
    <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>Quiz Statistics</h1>

      <Grid container spacing={2} style={styles.gridContainer}>
        <Grid item xs={12} sm={6} md={4}>
          <Paper style={styles.card} elevation={3}>
            <Typography variant="h5" style={styles.cardTitle}>
              Best Quiz <StarIcon style={styles.starIcon} />
            </Typography>
            <Divider />
            <Typography style={styles.cardContent}>
              Total Score: {statistics ? statistics.best_quiz_total_correct_answers + '/15' : 'N/A'}
            </Typography>
          </Paper>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Paper style={styles.card} elevation={3}>
            <Typography variant="h5" style={styles.cardTitle}>
              Last Quiz Score <StarIcon style={styles.starIcon} />
            </Typography>
            <Divider />
            <Typography style={styles.cardContent}>
              {statistics.latest_quiz_score + '/15' || 0}
            </Typography>
          </Paper>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Paper style={styles.card} elevation={3}>
            <Typography variant="h5" style={styles.cardTitle}>
              Total Quiz Attempts <StarIcon style={styles.starIcon} />
            </Typography>
            <Divider />
            <Typography style={styles.cardContent}>{statistics.total_quiz_attempts || 0}</Typography>
          </Paper>
        </Grid>

        <Grid item xs={12} sm={6} md={4}>
          <Paper style={styles.card} elevation={3}>
            <Typography variant="h5" style={styles.cardTitle}>
              Average Score <StarIcon style={styles.starIcon} />
            </Typography>
            <Divider />
            <Typography style={styles.cardContent}>{statistics.average_score || 0}</Typography>
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
};

export default QuizResults;
