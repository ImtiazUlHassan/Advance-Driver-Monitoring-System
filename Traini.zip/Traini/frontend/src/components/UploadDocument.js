import React, { useEffect, useState } from 'react';
import { Box, Button, Container, Typography, Input, Grid, Paper, List, ListItem, ListItemText, Divider, IconButton } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import axios from 'axios';
import DescriptionIcon from '@mui/icons-material/Description';
import DeleteIcon from '@mui/icons-material/Delete';
import { Link } from 'react-router-dom';

const UploadDocument = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [files, setFiles] = useState([]);

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/get_uploaded_files')
      .then((response) => {
        setFiles(response.data);
      })
      .catch((error) => {
        console.error('Error fetching files:', error);
      });
  }, []);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setSelectedFile(file);
  };

  const handleUpload = () => {
    if (selectedFile) {
      const formData = new FormData();
      formData.append('file', selectedFile);

      axios.post('http://127.0.0.1:8000/api/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      })
        .then((response) => {
          console.log(response.data);
          // Handle the API response here
        })
        .catch((error) => {
          console.error(error);
          // Handle any errors
        });
    } else {
      console.log('No file selected');
    }
  };

  const handleDeleteFile = (fileId) => {
    axios.delete(`http://127.0.0.1:8000/api/delete_file/${fileId}`)
      .then((response) => {
        if (response.status === 200) {
          setFiles(files.filter(file => file.id !== fileId));
        }
      })
      .catch((error) => {
        console.error('Error deleting file:', error);
      });
  };
  
  

  return (
    <Container maxWidth="md">
      <Paper elevation={3} style={{ padding: '20px', marginBottom: '20px' }}>
        <Box my={4}>
          <Typography variant="h4" component="h1" align="center">
            Upload Document
          </Typography>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <Input
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileChange}
                style={{ display: 'none' }}
                id="file-input"
              />
              <label htmlFor="file-input">
                <Button
                  variant="outlined"
                  color="primary"
                  fullWidth
                  component="span"
                  startIcon={<CloudUploadIcon />}
                >
                  Choose a File
                </Button>
              </label>
            </Grid>
            <Grid item xs={12}>
              <Button
                variant="contained"
                color="primary"
                fullWidth
                onClick={handleUpload}
              >
                Upload
              </Button>
            </Grid>
          </Grid>
        </Box>
      </Paper>
      <div>
        <Typography variant="h5" component="h2">
          Uploaded Files
        </Typography>
        <List>
          {files.map((file) => (
            <div key={file.id}>
              <ListItem button component={Link} to={`/document/${file.id}`}>
                <ListItemText
                  primary={file.file_name}
                  secondary={`Uploaded at: ${file.uploaded_at}`}
                />
              </ListItem>
              <Divider />
            </div>
          ))}
        </List>
      </div>
    </Container>
  );
};

export default UploadDocument;
