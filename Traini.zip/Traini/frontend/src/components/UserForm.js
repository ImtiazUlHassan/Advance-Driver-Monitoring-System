// UserForm.js
import React, { useState } from 'react';
import { Button, Grid, TextField, Select, MenuItem, FormControl, InputLabel } from '@mui/material';

const UserForm = ({ onSubmit, roles, userType }) => {
  const [user, setUser] = useState({
    username: '', // Change the name field to username
    email: '',
    phone: '',
    password: '',
    role: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser({ ...user, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(user);
    setUser({
      username: '', // Change the name field to username
      email: '',
      phone: '',
      password: '',
      role: '',
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <TextField
            label="Username" // Change the label to "Username"
            name="username" // Change the name field to username
            value={user.username} // Change the value to user.username
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Email"
            name="email"
            type="email"
            value={user.email}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Phone"
            name="phone"
            type="tel"
            value={user.phone}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12}>
          <TextField
            label="Password"
            name="password"
            type="password"
            value={user.password}
            onChange={handleChange}
            fullWidth
          />
        </Grid>
        <Grid item xs={12}>
          <FormControl fullWidth>
            <InputLabel>Role</InputLabel>
            <Select
              name="role"
              value={user.role}
              onChange={handleChange}
            >
              {roles.map((role) => (
                <MenuItem key={role} value={role}>
                  {role}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={12}>
          <Button type="submit" variant="contained" color="primary">
            Add {userType}
          </Button>
        </Grid>
      </Grid>
    </form>
  );
};

export default UserForm;
