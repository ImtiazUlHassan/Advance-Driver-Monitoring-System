import React, { useState, useEffect } from 'react';
import axios from 'axios';

const styles = {
  container: {
    maxWidth: '800px',
    margin: '0 auto',
    marginTop: '60px',
    padding: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    backgroundColor: '#f7f7f7',
    borderRadius: '10px',
    fontFamily: 'Arial, sans-serif',
  },
  title: {
    fontSize: '28px',
    fontWeight: 'bold',
    color: '#333',
    marginBottom: '20px',
    borderBottom: '2px solid #007bff',
    paddingBottom: '10px',
  },
  keyPoint: {
    fontSize: '18px',
    lineHeight: '1.6',
    color: '#444',
    margin: '15px 0',
  },
};

const LatestKeyPoint = () => {
  const [keyPoints, setKeyPoints] = useState([]);

  useEffect(() => {
    axios
      .get('http://127.0.0.1:8000/api/latestkeypoint')
      .then((response) => {
        const keyPointText = response.data.content;
        const keyPointList = keyPointText.split('\n').map((point, index) => {
          return index === 0 ? point : `${index}. ${point}`;
        });

        setKeyPoints(keyPointList);
      })
      .catch((error) => {
        console.error('Error fetching latest keypoint:', error);
      });
  }, []);

  return (
    <div style={styles.container}>
      <h1 style={styles.title}>Key Points</h1>
      <div>
        {keyPoints.map((point, index) => (
          <p key={index} style={styles.keyPoint}>
            {point}
          </p>
        ))}
      </div>
    </div>
  );
};

export default LatestKeyPoint;
