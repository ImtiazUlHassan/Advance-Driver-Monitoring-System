import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Quiz = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState(Array(questions.length).fill(''));
  const [showResults, setShowResults] = useState(false);
  const [userId, setUserId] = useState(null); // Initialize the user ID state

  useEffect(() => {
    // Fetch questions from your Django API
    axios.get('http://127.0.0.1:8000/api/questions')
      .then((response) => {
        setQuestions(response.data);
        const storedUserId = localStorage.getItem('userid');
        if (storedUserId) {
          setUserId(storedUserId); // Set the user ID state
        }
      })
      .catch((error) => {
        console.error('Error fetching questions:', error);
      });
      
  }, []);

  const handleAnswerSelect = (selectedOption) => {
    const updatedUserAnswers = [...userAnswers];
    updatedUserAnswers[currentQuestionIndex] = selectedOption;
    setUserAnswers(updatedUserAnswers);
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Show results if all questions have been answered
      setShowResults(true);

      // Calculate total correct and wrong answers
      const totalCorrectAnswers = questions.reduce((total, question, index) => {
        return userAnswers[index] === question[`option${question.correct_answer}`] ? total + 1 : total;
      }, 0);
      const totalWrongAnswers = questions.length - totalCorrectAnswers;

      // Calculate total score (if applicable)
      // Replace this calculation with your own scoring logic
      const totalScore = totalCorrectAnswers * 1; // Assumes each correct answer is worth 10 points

      // Send quiz results to the API
      sendQuizResultsToAPI(userId, totalCorrectAnswers, totalWrongAnswers, totalScore);
    }
  };

  const sendQuizResultsToAPI = (userId, totalCorrectAnswers, totalWrongAnswers, totalScore) => {
    axios.post('http://127.0.0.1:8000/api/savequizresult', {
      userId,
      totalCorrectAnswers,
      totalWrongAnswers,
      totalScore,
    })
      .then((response) => {
        console.log('Quiz results saved successfully:', response.data.message);
      })
      .catch((error) => {
        console.error('Failed to save quiz results:', error);
      });
  };

  const handleRestartQuiz = () => {
    // Reset quiz state to start over
    setCurrentQuestionIndex(0);
    setUserAnswers(Array(questions.length).fill(''));
    setShowResults(false);
  };

  const getQuestionStatus = (question, userAnswer) => {
    if (userAnswer === question[`option${question.correct_answer}`]) {
      return 'correct';
    } else if (userAnswer !== '') {
      return 'wrong';
    }
    return '';
  };

  const getTotalCorrectAnswers = () => {
    return questions.reduce((total, question, index) => {
      return userAnswers[index] === question[`option${question.correct_answer}`] ? total + 1 : total;
    }, 0);
  };

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: '800px', margin: '0 auto',marginTop:'100px', padding: '20px', boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)' }}>
      {showResults ? (
        <div style={{ textAlign: 'center' }}>
          <h1>Quiz Results</h1>
          <p style={{ fontSize: '18px' }}>You answered {getTotalCorrectAnswers()} out of {questions.length} questions correctly.</p>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {questions.map((question, index) => (
              <li key={index} style={{ marginBottom: '20px', padding: '20px', background: '#f7f7f7', border: '1px solid #ddd' }}>
                <strong style={{ fontSize: '20px', display: 'block', marginBottom: '10px' }}>{question.question_text}</strong>
                <p style={{ fontSize: '16px', marginBottom: '10px' }}>Your Answer: {userAnswers[index]}</p>
                <p style={{ fontSize: '16px' }}>Correct Answer: {question[`option${question.correct_answer}`]}</p>
              </li>
            ))}
          </ul>
          <button
            onClick={handleRestartQuiz}
            style={{
              background: '#007bff',
              color: 'white',
              fontSize: '16px',
              padding: '10px 20px',
              border: 'none',
              cursor: 'pointer',
              marginTop: '20px',
              borderRadius: '5px',
            }}
          >
            Restart Quiz
          </button>
        </div>
      ) : (
        <div>
          <h1>Question {currentQuestionIndex + 1}</h1>
          <p style={{ fontSize: '18px' }}>{questions[currentQuestionIndex]?.question_text}</p>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            {['option1', 'option2', 'option3', 'option4'].map((option, index) => (
              <li key={index} style={{ marginBottom: '10px' }}>
                <label style={{ fontSize: '16px', display: 'flex', alignItems: 'center' }}>
                  <input
                    type="radio"
                    value={questions[currentQuestionIndex]?.[option]}
                    checked={userAnswers[currentQuestionIndex] === questions[currentQuestionIndex]?.[option]}
                    onChange={() => handleAnswerSelect(questions[currentQuestionIndex]?.[option])}
                  />
                  {questions[currentQuestionIndex]?.[option]}
                </label>
              </li>
            ))}
          </ul>
          <button
            onClick={handleNextQuestion}
            style={{
              background: '#007bff',
              color: 'white',
              fontSize: '16px',
              padding: '10px 20px',
              border: 'none',
              cursor: 'pointer',
              marginTop: '20px',
              borderRadius: '5px',
            }}
          >
            {currentQuestionIndex === questions.length - 1 ? 'Finish Quiz' : 'Next Question'}
          </button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
