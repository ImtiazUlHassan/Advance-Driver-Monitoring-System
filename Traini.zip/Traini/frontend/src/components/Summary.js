import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Summary = () => {
  const [latestSummary, setLatestSummary] = useState('');

  useEffect(() => {
    axios
      .get('http://127.0.0.1:8000/api/latestsummary')
      .then((response) => {
        setLatestSummary(response.data.content);
      })
      .catch((error) => {
        console.error('Error fetching latest summary:', error);
      });
  }, []);

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Summary</h2>
      <p style={styles.summaryText}>{latestSummary}</p>
    </div>
  );
};

const styles = {
  container: {
    fontFamily: 'Arial, sans-serif',
    maxWidth: '800px',
    margin: '0 auto',
    marginTop:'70px',
    padding: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    backgroundColor: '#f9f9f9',
    borderRadius: '10px',
  },
  title: {
    fontSize: '32px',
    color: '#333',
    marginBottom: '20px',
    textAlign: 'center',
    fontFamily: 'cursive',
  },
  summaryText: {
    fontSize: '20px',
    lineHeight: '1.6',
    color: '#555',
    textAlign: 'justify',
    fontFamily: 'Georgia, serif',
  },
};

export default Summary;
