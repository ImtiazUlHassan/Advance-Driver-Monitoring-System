import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

import { Button, TextField, Container, Typography, Box, Paper, CssBaseline } from '@mui/material';
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';

const Login = () => {
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate(); // Access the navigate function

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleLogin = async () => {
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/login/', formData);
      console.log("User Id",response.data)
      const { token, role,user_id } = response.data;

      // Store the token in localStorage or a secure storage method
      localStorage.setItem('token', token);
      localStorage.setItem('userRole', role);
      localStorage.setItem('userid', user_id);

   
      // Determine where to navigate based on the user's role
      if (role === 'superadmin') {

        navigate('/super-admin'); 
        window.location.reload();
        // Use navigate to go to the desired route
      } else if (role === 'admin') {
        navigate('/admin'); 
        window.location.reload();
        // Use navigate to go to the desired route
      } else if (role === 'trainee') {
        navigate('/trainee'); 
        window.location.reload();
        // Use navigate to go to the desired route
      }
    } catch (error) {
      setError('Invalid username or password');
    }
  };

  return (
    <Container component="main" maxWidth="sm" sx={{mt:10}}>
      <CssBaseline /> {/* Add CssBaseline here */}
      <Paper elevation={3} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px' }}>
        <LockOutlinedIcon color="primary" style={{ fontSize: 72 }} />
        <Typography variant="h5">Login</Typography>
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          id="username"
          label="Username"
          name="username"
          autoComplete="username"
          autoFocus
          onChange={handleChange}
        />
        <TextField
          variant="outlined"
          margin="normal"
          required
          fullWidth
          name="password"
          label="Password"
          type="password"
          id="password"
          autoComplete="current-password"
          onChange={handleChange}
        />
        {error && <Typography color="error">{error}</Typography>}
        <Button
          type="button"
          fullWidth
          variant="contained"
          color="primary"
          onClick={handleLogin}
        >
          Sign In
        </Button>
      </Paper>
    </Container>
  );
};



export default Login;
