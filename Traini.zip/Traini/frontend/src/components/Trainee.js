import React, { useState } from 'react';
import UserForm from './UserForm';
import QuizResults from './QuizResults';

function Trainee() {
  const [trainees, setTrainees] = useState([]);

  const addTrainee = (trainee) => {
    setTrainees([...trainees, trainee]);
  };
// Trainee.js
// ...
const roles = [];
// ...

  return (
    <div style={{ margin: '0 auto',marginTop:'100px',}}>
      <QuizResults/>
{/* <UserForm onSubmit={addUser} roles={roles} userType="Trainee" /> */}
      {/* <TraineeList trainees={trainees} /> */}
    </div>
  );
}

export default Trainee;
