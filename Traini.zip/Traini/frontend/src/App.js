import React, { useState } from 'react';
import { CssBaseline, Container } from '@mui/material';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Layout/Header';
import Sidebar from './components/Layout/Sidebar';
import SuperAdminPage from './components/SuperAdmin';
import AdminPage from './components/Admin';
import TraineePage from './components/Trainee';
import LoginPage from './components/LoginPage';
import UploadDocument from './components/UploadDocument';
import DocumentDetail from './components/DocumentDetail'; // Import the DocumentDetail component
import Quiz from './components/Quiz'; // Import the DocumentDetail component

import QuizResults from './components/QuizResults'; // Import the DocumentDetail component
import Summary from './components/Summary';
import LatestKeyPoint from './components/Key';
import ChatBot from './components/ChatBot';
import AdminUserList from './components/AdminList';
import TraineeUserList from './components/TraineeList';

const isAuthenticated = () => {
  return !!localStorage.getItem('token');
};

const ProtectedRoute = ({ element, ...rest }) => {
  return isAuthenticated() ? element : <Navigate to="/login" />;
};
const determineUserRole = () => {
  return localStorage.getItem('userRole');
};


const App = () => {
  const userRole = determineUserRole();


  const [openSidebar, setOpenSidebar] = useState(true);

  const handleSidebarToggle = () => {
    setOpenSidebar(!openSidebar);
  };


  return (
    <Router>
      <div>
        <CssBaseline />
        <Routes>
        <Route
  path="/"
  element={
    userRole === 'superadmin' ? (
      <Navigate to="/super-admin" />
    ) : userRole === 'admin' ? (
      <Navigate to="/admin" />
    ) : userRole === 'trainee' ? (
      <Navigate to="/trainee" />
    ) : (
      <LoginPage />
    )
  }
/>

          <Route path="/login" element={<LoginPage />} />
          <Route path="/document/:id" element={<DocumentDetail />} /> 
          {userRole === 'superadmin' && (
          <Route
            path="/super-admin"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <SuperAdminPage />
                    </Container>
                  </div>
                }
              />
            }
          />
          )}
               {userRole === 'superadmin' && (
          <Route
            path="/adminlist"
            element={
              <ProtectedRoute
                element={
                  <div>
                  <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <AdminUserList />
                    </Container>
                  </div>
                }
              />
            }
          />)}
                {userRole === 'superadmin' &&  (
          <Route
            path="/traineelist"
            element={
              <ProtectedRoute
                element={
                  <div>
                  <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <TraineeUserList />
                    </Container>
                  </div>
                }
              />
            }
          />)}
             {userRole === 'admin' &&  (
          <Route
            path="/traineelist"
            element={
              <ProtectedRoute
                element={
                  <div>
                  <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <TraineeUserList />
                    </Container>
                  </div>
                }
              />
            }
          />)}
              {userRole === 'admin' && (
          <Route
            path="/admin"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} userRole={userRole} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <AdminPage />
                    </Container>
                  </div>
                }
              />
            }
          />)}
                    {userRole === 'trainee' && (

          <Route
            path="/trainee"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <TraineePage />
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
          )}
          {userRole === 'trainee' && (
  <Route
            path="/quiz"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <Quiz />
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
          )}
           {userRole === 'trainee' && (
           <Route
            path="/quizresult"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <QuizResults />
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
           )}
            {userRole === 'trainee' && (
               <Route
            path="/keypoint"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <LatestKeyPoint />
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
            )}
             {userRole === 'trainee' && (
              <Route
            path="/summary"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <Summary />
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
             )}
              {userRole === 'trainee' && (      
              <Route
            path="/chat"
            element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar open={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <ChatBot/>
                    </Container>
                  </div>
                }
              />
              
            }
            
          />
              )}
               {userRole === 'admin' && (
           <Route path="/upload" element={
              <ProtectedRoute
                element={
                  <div>
                    <Header handleSidebarToggle={handleSidebarToggle} openSidebar={openSidebar} />
                    <Sidebar openSidebar={openSidebar} handleSidebarToggle={handleSidebarToggle} userRole={userRole} />
                    <Container
                      maxWidth="lg"
                      style={{ marginLeft: openSidebar ? '250px' : '0', padding: '20px' }}
                    >
                      <UploadDocument />
                    </Container>
                  </div>
                }
              />
            } />
               )}
        </Routes>
       

      </div>
    </Router>
  );
};

export default App;
