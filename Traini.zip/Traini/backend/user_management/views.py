from django.shortcuts import render
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.authtoken.views import ObtainAuthToken
from rest_framework.authtoken.models import Token
from django.contrib.auth import get_user_model
from .serializers import KeyPointSerializer, QuizQuestionSerializer, QuizResultsSerializer, SummarySerializer, UserLoginSerializer, AdminUserSerializer, TraineeUserSerializer, UserSerializer
from user_management.models import *
from django.contrib.auth.hashers import make_password
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import os
from rest_framework import generics
from rest_framework import permissions
from django.db.models import Avg, Count, Max, Sum

User = get_user_model()

# from django.http import JsonResponse
#sfrom langchain import OpenAIEmbeddings, FAISS, CharacterTextSplitter, OpenAI
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain import FAISS
from langchain.chains.question_answering import load_qa_chain
from langchain.llms import OpenAI

from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter

os.environ['OPENAI_API_KEY'] = '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'

def create_knowledge_base(pdf_file_path):
    # Read the PDF file
    pdf_reader = PdfReader(pdf_file_path)
    text = ""
    pageno = 0
    for page in pdf_reader.pages:
        pageNoinfo = "\t this page Number is :" + str(pageno)
        text += (page.extract_text() + pageNoinfo)
        pageno = pageno + 1

    # Split into chunks
    text += "Total number of pages in this document is:" + str(pageno)
    text_splitter = CharacterTextSplitter(
        separator="\n",
        chunk_size=1000,
        chunk_overlap=200,
        length_function=len
    )
    chunks = text_splitter.split_text(text)

    # Create embeddings
    embeddings = OpenAIEmbeddings()
    knowledge_base = FAISS.from_texts(chunks, embeddings)

    return knowledge_base


@api_view(['GET', 'POST'])
def generateSummary(request):
    document_id = request.data.get('id')
    user_input=request.data.get('userinput')

    try:
        document = Document.objects.get(id=document_id)
        print("Document path")
        print(document.file.path)
        
        
        embeddings = OpenAIEmbeddings()
        knowledge_base = create_knowledge_base(document.file.path)
        docs = knowledge_base.similarity_search(user_input)
        print(knowledge_base)

        llm = OpenAI(model_name='gpt-3.5-turbo')

        chain = load_qa_chain(llm, chain_type='stuff')
        response=chain.run(input_documents=docs, question=user_input)
        # response = llm.answer(user_input, documents=knowledge_base)

        return Response({'summary': response})
    except Document.DoesNotExist:
        return Response({'error': 'Document not found'})



class UserLoginAPI(ObtainAuthToken):
    serializer_class = UserLoginSerializer

    def post(self, request, *args, **kwargs):
        print(request.data)
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data['user']
            print(user.id)
            role = self.determine_user_role(user)
            if role:
                token, created = Token.objects.get_or_create(user=user)
                return Response({
                    'token': token.key,
                    'role': role,
                      'user_id': user.id,
                })
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def determine_user_role(self, user):
        print(user.role)
        # Check the user's role from the database field
        role = user.role
        if role == 'superadmin':
            return 'superadmin'
        elif role == 'admin':
            return 'admin'
        elif role == 'trainee':
            return 'trainee'
        else:
            return None

class UserTokenAPI(APIView):
    def post(self, request):
        token, created = Token.objects.get_or_create(user=request.user)
        return Response({'token': token.key}, status=status.HTTP_200_OK)

class AdminUserCreateView(APIView):
    def post(self, request):
        data = request.data
        data['password'] = make_password(data['password'])  # Hash the password
        serializer = AdminUserSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class TraineeUserCreateView(APIView):
    def post(self, request):
        data = request.data
        data['password'] = make_password(data['password'])  
        serializer = TraineeUserSerializer(data=data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
@csrf_exempt  
def upload_file(request):
    if request.method == 'POST' and request.FILES['file']:
        uploaded_file = request.FILES['file']

        document = Document(file=uploaded_file)
        document.save()

        return JsonResponse({'message': 'File uploaded successfully'})
    else:
        return JsonResponse({'message': 'File upload failed'}, status=400)

def get_uploaded_files(request):
    documents = Document.objects.all()
    file_data = []

    for document in documents:
        file_data.append({
            'id': document.id,
            'file_name': document.file.name,
            'uploaded_at': document.uploaded_at.strftime('%Y-%m-%d %H:%M:%S'),
        })

    return JsonResponse(file_data, safe=False)

@csrf_exempt
def delete_file(request, file_id):
    try:
        file_to_delete = Document.objects.get(id=file_id)
        file_to_delete.delete()
        return JsonResponse({'message': 'File deleted successfully'})
    except Document.DoesNotExist:
        return JsonResponse({'error': 'File not found'}, status=404)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)
    
@api_view(['POST'])
def save_summary(request):
    content = request.data.get('content')
    document_id = request.data.get('document_id')
    
    document = Document.objects.get(id=document_id)
    
    summary = Summary(content=content, document=document)
    summary.save()
    
    return Response({'message': 'Summary saved successfully'})


@api_view(['POST'])
def save_quiz(request):
    questions_data = request.data.get('questions')
    
    questions = []
    
    for question_data in questions_data:
        text = question_data['text']
        choices_data = question_data['choices']
        
        question = Question.objects.create(text=text)
        
        for choice_data in choices_data:
            text = choice_data['text']
            is_correct = choice_data['is_correct']
            choice = Choice.objects.create(question=question, text=text, is_correct=is_correct)
        
        questions.append(question)

    return Response({'message': 'Quiz saved successfully'}, status=status.HTTP_201_CREATED)

@api_view(['POST'])
def save_keypoint(request):
    content = request.data.get('content')
    document_id = request.data.get('document_id')  

    document = Document.objects.get(id=document_id)
    
    keypoint = KeyPoint(content=content, document=document)
    keypoint.save()
    
    return Response({'message': 'KeyPoint saved successfully'})
@api_view(['POST'])
def save_quiz(request):
    if request.method == 'POST':
        data = request.data.get('questions', [])  # Extract 'questions' from the dictionary
        serializer = QuizQuestionSerializer(data=data, many=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Quiz saved successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class QuizQuestionList(generics.ListCreateAPIView):
    queryset = QuizQuestion.objects.all()
    serializer_class = QuizQuestionSerializer

class SaveQuizResults(APIView):
    def post(self, request):
        user_id = request.data.get('userId')
        total_correct_answers = request.data.get('totalCorrectAnswers')
        total_wrong_answers = request.data.get('totalWrongAnswers')
        total_score = request.data.get('totalScore')

        try:
            user = User.objects.get(id=user_id)
            quiz_results = QuizResults(user=user, total_correct_answers=total_correct_answers, total_wrong_answers=total_wrong_answers, total_score=total_score)
            quiz_results.save()
            return Response({'message': 'Quiz results saved successfully'}, status=status.HTTP_201_CREATED)
        except User.DoesNotExist:
            return Response({'message': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        
class QuizResultsList(generics.ListAPIView):
    serializer_class = QuizResultsSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, *args, **kwargs):
        user = request.user
        best_quiz = QuizResults.objects.filter(user=user).order_by('-total_score').first()
        total_quiz_attempts = QuizResults.objects.filter(user=user).count()
        best_correct_answers = best_quiz.total_correct_answers if best_quiz else 0
        best_wrong_answers = best_quiz.total_wrong_answers if best_quiz else 0
        average_score = (
            QuizResults.objects.filter(user=user)
            .aggregate(Avg('total_score'))['total_score__avg']
        )
        latest_score = QuizResults.objects.filter(user=user).order_by('-id').first()
        latest_quiz_score = latest_score.total_score if latest_score else 0
        data = {
            'best_quiz_total_correct_answers': best_correct_answers,
            'best_quiz_total_wrong_answers': best_wrong_answers,
            'total_quiz_attempts': total_quiz_attempts,
            'average_score': average_score,
            'latest_quiz_score': latest_quiz_score,
        }
        return Response(data)
    
class LatestSummaryView(generics.RetrieveAPIView):
    queryset = Summary.objects.order_by('-id')
    serializer_class = SummarySerializer
    lookup_field = 'id'  # Specify the lookup field

    def get_object(self):
        # Override the default get_object method to get the latest summary
        return self.queryset.first()
    
class LatestKeyPointView(generics.RetrieveAPIView):
    serializer_class = KeyPointSerializer

    def get(self, request, *args, **kwargs):
        # Retrieve the latest keypoint
        latest_keypoint = KeyPoint.objects.order_by('-id').first()

        if latest_keypoint:
            serializer = self.get_serializer(latest_keypoint)
            return Response(serializer.data)
        else:
            return Response({'detail': 'No keypoint found.'}, status=status.HTTP_404_NOT_FOUND)

class AdminUserListView(generics.ListAPIView):
    queryset = User.objects.filter(role='admin')
    serializer_class = UserSerializer
class TraineeListView(generics.ListAPIView):
    queryset = User.objects.filter(role='trainee')
    serializer_class = UserSerializer

class AdminUserDeleteView(APIView):

    def delete(self, request):
        user_id = request.data.get('id')
        try:
            user = User.objects.get(id=user_id, role='admin')
            user.delete()
            return Response({'Msg':"Deleted Sucessful"},status=200)
        except User.DoesNotExist:
            return Response("Admin user not found", status=status.HTTP404_NOT_FOUND)
class TraineeDeleteView(APIView):

    def delete(self, request):
        user_id = request.data.get('id')
        try:
            user = User.objects.get(id=user_id, role='trainee')
            user.delete()
            return Response({'Msg':"Deleted Sucessful"},status=200)
        except User.DoesNotExist:
            return Response("Trainee user not found", status=status.HTTP404_NOT_FOUND)