from django.contrib.auth.models import AbstractUser
from django.db import models

class CustomUser(AbstractUser):
    # Add the role field to the User model
    role = models.CharField(max_length=20, default='superadmin')  # Set the default role

    def __str__(self):
        return self.username
class Document(models.Model):
    id=models.IntegerField(primary_key=True)
    file = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

class Summary(models.Model):
    id = models.AutoField(primary_key=True)
    content = models.TextField()
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='summaries')

class QuizQuestion(models.Model):
    question_text = models.CharField(max_length=200)
    option1 = models.CharField(max_length=200)
    option2 = models.CharField(max_length=200)
    option3 = models.CharField(max_length=200)
    option4 = models.CharField(max_length=200)
    correct_answer = models.PositiveSmallIntegerField()

class KeyPoint(models.Model):
    id = models.AutoField(primary_key=True)
    content = models.TextField()
    document = models.ForeignKey(Document, on_delete=models.CASCADE, related_name='key_points')

class QuizResults(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE)  
    total_correct_answers = models.IntegerField()
    total_wrong_answers = models.IntegerField()
    total_score = models.IntegerField()