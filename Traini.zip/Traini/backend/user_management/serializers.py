from rest_framework import serializers
from django.contrib.auth import get_user_model
from rest_framework.authtoken.models import Token
from user_management.models import *

User = get_user_model()

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'role']


class UserLoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField(write_only=True)
    user = None  # Placeholder for the user object

    def validate(self, data):
        username = data.get('username')
        password = data.get('password')

        user = User.objects.get(username=username)  # Adjust this based on your authentication logic
        if user.check_password(password):
            data['user'] = user  # Set the 'user' key in validated_data
            print(data)
            return data

        raise serializers.ValidationError("Invalid username or password")

class UserTokenSerializer(serializers.ModelSerializer):
    class Meta:
        model = Token
        fields = ('key',)

class AdminUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

class TraineeUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
class QuizQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuizQuestion
        fields = '__all__'

class QuizResultsSerializer(serializers.ModelSerializer):
    class Meta:
        
        model = QuizResults
        fields = ('user', 'total_correct_answers', 'total_wrong_answers', 'total_score')

class SummarySerializer(serializers.ModelSerializer):
    class Meta:
        model = Summary
        fields = '__all__'

class KeyPointSerializer(serializers.ModelSerializer):
    class Meta:
        model = KeyPoint
        fields = ('id', 'content', 'document')