from django.contrib import admin

from user_management.models import QuizQuestion

# Register your models here.

admin.site.register(QuizQuestion)