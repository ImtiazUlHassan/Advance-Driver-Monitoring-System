# user_management/urls.py

from django.urls import path
from .views import AdminUserCreateView, TraineeUserCreateView,TraineeDeleteView,AdminUserDeleteView,TraineeListView,QuizQuestionList,SaveQuizResults,QuizResultsList,LatestSummaryView,AdminUserListView
from .views import UserLoginAPI, UserTokenAPI
from user_management.models import CustomUser
from .views import*


urlpatterns = [
    path('login/', UserLoginAPI.as_view(), name='user-login'),
    path('token/', UserTokenAPI.as_view(), name='user-token'),
    path('admin/create/', AdminUserCreateView.as_view(), name='admin-user-create'),
    path('api/trainee/create/', TraineeUserCreateView.as_view(), name='trainee-user-create'),
    path('upload', upload_file, name='upload_file'),
    path('get_uploaded_files', get_uploaded_files, name='get_uploaded_files'),
    path('delete_file/<int:file_id>', delete_file, name='delete_file'),
    path('generatesummary', generateSummary, name='generatesummary'),
    path('savesummary', save_summary, name='savesummary'),
    path('savequiz', save_quiz, name='savequiz'),
    path('savekeypoint', save_keypoint, name='savekeypoint'),
    path('questions', QuizQuestionList.as_view(), name='quiz-questions'),
    path('savequizresult', SaveQuizResults.as_view(), name='savequizresult'),
    path('quiz-results', QuizResultsList.as_view(), name='savequizresult'),
    path('latestsummary', LatestSummaryView.as_view(), name='latest-summary'),
    path('latestkeypoint', LatestKeyPointView.as_view(), name='latest-keypoint'),
    path('admin-users', AdminUserListView.as_view(), name='admin-users-list'),
    path('trainee-users', TraineeListView.as_view(), name='admin-users-list'),
    path('deleteadmin',AdminUserDeleteView.as_view(), name='admin-user-delete'),
    path('deletetrainee',TraineeDeleteView.as_view(), name='admin-user-delete'),



]
